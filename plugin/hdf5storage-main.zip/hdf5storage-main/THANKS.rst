The following people helped contributed code to fix bugs, add features, etc.

* `Max Bolingbroke <https://github.com/batterseapower>`_
* `Steven Dee <https://github.com/mrdomino>`_
* `Daniel Hrisca <https://github.com/danielhrisca>`_
* `WANG Longqi <https://github.com/wanglongqi>`_
* `Jakub Urban <https://github.com/coobas>`_
* `Ghislain Antony Vaillant <https://github.com/ghisvail>`_

