Overview
========

This is an example plugin package for providing Marshallers for the
`hdf5storage <https://pypi.python.org/pypi/hdf5storage>`_ package (this
example package is included in it).

The base package's documetation is found at
http://pythonhosted.org/hdf5storage/

The base package's source code is found at
https://github.com/frejanordsiek/hdf5storage
with this example packages source code being at
https://github.com/frejanordsiek/hdf5storage/tests/example_hdf5storage_marshaller_plugin

The package is licensed under a 2-clause BSD license
(https://github.com/frejanordsiek/hdf5storage/blob/master/COPYING.txt).
