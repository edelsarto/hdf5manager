.. hdf5storage documentation master file, created by
   sphinx-quickstart on Sun Dec 22 00:05:54 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to hdf5storage's documentation!
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   information
   introduction
   paths
   compression
   storage_format
   development
   thanks
   api_for_users
   api_for_plugins_developers

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

