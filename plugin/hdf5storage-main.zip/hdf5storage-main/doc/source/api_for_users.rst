API for Users
=============

The external API meant for users of this package.

.. toctree::
   :maxdepth: 2

   hdf5storage
   hdf5storage.exceptions
   hdf5storage.pathesc
