hdf5storage.exceptions
======================

.. currentmodule:: hdf5storage.exceptions

.. automodule:: hdf5storage.exceptions

.. autosummary::
   
   Hdf5storageError
   CantReadError
   TypeNotMatlabCompatibleError


Hdf5storageError
----------------

.. autoexception:: Hdf5storageError
   :show-inheritance:


CantReadError
-------------

.. autoexception:: CantReadError
   :show-inheritance:


TypeNotMatlabCompatibleError
----------------------------

.. autoexception:: TypeNotMatlabCompatibleError
   :show-inheritance:

