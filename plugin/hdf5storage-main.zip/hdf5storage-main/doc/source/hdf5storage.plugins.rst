hdf5storage.plugins
===================

.. currentmodule:: hdf5storage.plugins

.. automodule:: hdf5storage.plugins

.. autosummary::

   find_thirdparty_marshaller_plugins
   supported_marshaller_api_versions


find_thirdparty_marshaller_plugins
----------------------------------

.. autofunction:: find_thirdparty_marshaller_plugins


supported_marshaller_api_versions
---------------------------------

.. autofunction:: supported_marshaller_api_versions
